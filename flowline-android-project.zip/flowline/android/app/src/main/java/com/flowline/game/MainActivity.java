package com.flowline.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
